# Courier-management-system
Description:

This is a simple courier management system which can be used by an organization to track packages recieved.

# Features

1.Login page(for admin and users)

2.admins can add packages with relevant fields.

3.users can view all the packages recieved and search for theirs using their username.

4.password reset system for the users.

# Technology used:

backend: python3, django.

frontend: bootstrap.
